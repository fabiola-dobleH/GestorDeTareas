
package principal;

import vista.FormInicio;
import vista.Registro;

public class Principal {

   
    public static void main(String[] args) {
      FormInicio formInicio=new FormInicio();
      formInicio.setVisible(true);
      
    }
    
}
